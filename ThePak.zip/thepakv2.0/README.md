PANDUAN ThePakByPass

*Download ThePakByPass https://www.mediafire.com/download/zt9c4975zzm4j7e
dan Ekstrak ke folder /Download/

*Download Termux di PlayStore dan ijinkan penyimpanannya di pengaturan aplikasi

*Buka Termux dan jalankan perintah dibawah ini


apt update

apt upgrade

Y

Y

Y

Y

apt update

pkg upgrade

pkg update

pkg install git

Y

pkg install wget

Y

sh $EXTERNAL_STORAGE/Download/ThePakByPass.sh

cd the*

chmod +x setup

bash setup

1

CTRL + C

bash setup

CTRL + C

exit

*SELESAI

*salin dan tempel file PAK yg akan di edit ke folder Download/pak
*buka termux dan jalankan perintah dibawah ini utk memulai

cd the*

chmod +x setup

bash setup

*siapkan secangkir kopi utk menemani kalian mengedit PAK nya ?

*Group Telegram
GAMINGAN https://t.me/gamingantele

*Youtube Channel
Gamingan TV https://youtube.com/channel/UCSEu-uMD5s8b2x8CVjQrBCA